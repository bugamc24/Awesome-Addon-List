local addonName, namespace = ...

local function getEnchZone(itemId)
	local getEnchZone = ""
	
	--Battle for Azeroth
	if itemId == "152877" then --Veiled Crystal
		getEnchZone = "Gathered from disenchanting\nEpic quality Battle for Azeroth items."
	elseif itemId == "152876" then --Umbra Shard
		getEnchZone = "Gathered from disenchanting\nRare quality Battle for Azeroth items."
	elseif itemId == "152875" then --Gloom Dust
		getEnchZone = "Gathered from disenchanting\nUncommon quality Battle for Azeroth items."
	--Legion
	elseif itemId == "124442" then --Chaos Crystal
		getEnchZone = "Gathered from disenchanting\nEpic quality Legion items."
	elseif itemId == "124441" then --Leylight Shard
		getEnchZone = "Gathered from disenchanting\nRare quality Legion items."
	elseif itemId == "124440" then --Arkhana
		getEnchZone = "Gathered from disenchanting\nUncommon quality Legion items."
	elseif itemId == "156930" then --Rich Illusion Dust
		getEnchZone = "Gathered from disenchanting\nUncommon quality Legion items."  -- THIS NEEDS TO BE CHECKED IN GAME!!!!!!!!!!
	end
	
	return getEnchZone
end


namespace.enchName = getEnchZone
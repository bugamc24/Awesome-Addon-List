local addonName, namespace = ...

local function getMetalsZone(itemId)
	local smetalsZone = ""
	
	--Battle for Azeroth
	if itemId == "152513" then --Platinum Ore
		smetalsZone = "Gathered across Zandalar & Kul'tiras. Rare."
	elseif itemId == "152579" then --Storm Silver Ore
		smetalsZone = "Gathered across Zandalar & Kul'tiras. Uncommon."
	elseif itemId == "152512" then --Monelite
		smetalsZone = "Gathered across Zandalar & Kul'tiras. Common."
	elseif itemId == "168185" then--Osmenite Ore
		smetalsZone = "Gathered across Nazjatar."
	--Legion Ore
	elseif itemId == "151564" then --Empyrium
		smetalsZone = "Gathered across Argus."
	elseif itemId == "124444" then --Infernal Brimstone
		smetalsZone = "Gathered from a World Quest on The Broken Isles."
	elseif itemId == "123919" then --Felslate
		smetalsZone = "Gathered across The Broken Isles."
	elseif itemId == "123918" then --Leystone
		smetalsZone = "Gathered across The Broken Isles."
	--Legion Bars
	elseif itemId == "124461" then --Demonsteel Bar
		smetalsZone = "Smelted by Blacksmiths\nusing Leystone Ore\n2 Felslate"
	--Warlords of Draenor Ore
	elseif itemId == "109118" then --Blackrock Ore
		smetalsZone = "Gathered across Draenor\nMost common in: Nagrand & Talador."
	elseif itemId == "109119" then --True Iron Ore
		smetalsZone = "Gathered across Draenor\nMost common in: Nagrand & Talador."
	--Warlords of Draenor Bars
	elseif itemId == "108257" then --Truesteel Bar
		smetalsZone = "Smelted by Blacksmiths using:\n20 True Iron & 10 Blackrock"
	--Mists of Pandaria Ore
	elseif itemId == "72093" then --Kyparite
		smetalsZone = "Gathered in: Dread Wastes & Townlong Steppes."
	elseif itemId == "72092" then --Ghost Iron Ore
		smetalsZone = "Gathered across Pandaria."
	elseif itemId == "72103" then --White Trillium
		smetalsZone = "Gathered across Pandaria.\nMost common in: Dread Wastes & Townlong Steppes."
	elseif itemId == "72094" then --Black Trillium
		smetalsZone = "Gathered across Pandaria.\nMost common in: Dread Wastes & Townlong Steppes."
	--Mists of Pandaria Bars
	elseif itemId == "72096" then --Ghost Iron Bar
		smetalsZone = "Smelted by Miners using:\n2 Ghost Iron Ore"
	elseif itemId == "72095" then --Trillium Bar
		smetalsZone = "Smelted by Miners using 2 Black & 2 White Trillium.\nTransmuted by Alchemists using 10 Ghost Iron Ore."
	elseif itemId == "72104" then --Living Steel
		smetalsZone = "Transmuted by Alchemists using 3 Trillium Bars\n3 Spirit of Harmony"
	--Cataclysm Ore
	elseif itemId == "52183" then --Pyrite
		smetalsZone = "Gathered in: Twilight Highlands,\nUldum & Tol Barad."
	elseif itemId == "52185" then --Elementium
		smetalsZone = "Gathered in: Deepholm & Twilight Highlands."
	elseif itemId == "53038" then --Obsidium
		smetalsZone = "Gathered in: Deepholm & Mount Hyjal."
	--Cataclysm Bars
	elseif itemId == "54849" then --Obsidium
		smetalsZone = "Smelted by Miners using:\n2 Obsidium Ore"
	elseif itemId == "65365" then --Folded Obsidium
		smetalsZone = "Created by Blacksmiths using:\n2 Obsidium Bars"
	elseif itemId == "53039" then --Hardened Elementium Bar
		smetalsZone = "Smelted by Miners using:\n10 Elementium Bars\n4 Volatile Earth"
	elseif itemId == "52186" then --Elementium Bar
		smetalsZone = "Smelted by Miners using:\n2 Elementium Ore"
	elseif itemId == "58480" then --Truegold
		smetalsZone = "Transmuted by Alchemists using:\n3 Pyrite Bars\n10 Volatile Fire, Air & Water"
	elseif itemId == "51950" then --Pyrium
		smetalsZone = "Smelted by Miners using: 2 Pyrite Ore.\nTransmuted by Alchemists using: Elementium Bar & Volatile Earth"
	--Wrath of the Lich King Ore
	elseif itemId == "36910" then --Titanium
		smetalsZone = "Gathered in: Icecrown,\nThe Storm Peaks, Sholazar Basin & Wintergrasp."
	elseif itemId == "36909" then --Cobalt Ore
		smetalsZone = "Gathered in: Zul'Drak,\nHowling Fjord & Borean Tundra."
	elseif itemId == "36912" then --Saronite
		smetalsZone = "Gathered in: Icecrown,\nSholazar Basin & The Storm Peaks."
	--Wrath of the Lich King Bars
	elseif itemId == "37663" then --Titansteel Bar
		smetalsZone = "Smelted by Miners using:\n3 Titanium Bars\n1 Eternal Fire, Earth & Shadow"
	elseif itemId == "41163" then --Titanium
		smetalsZone = "Smelted by Miners using: 2 Titanium Ore\nTransmuted by Alchemists using: 8 Saronite Bars"
	elseif itemId == "36913" then --Saronite Bar
		smetalsZone = "Smelted by Miners using:\n2 Saronite Ore."
	elseif itemId == "36916" then --Cobalt Bar
		smetalsZone = "Smelted by Miners using:\n 1 Cobalt Ore"
	--The Burning Crusade Ore
	elseif itemId == "23426" then --Khorium
		smetalsZone = "Gathered in: Nagrand,\nBlade's Edge Mountains, Netherstorm\n&Shadowmoon Valley(Outland)."
	elseif itemId == "23427" then --Eternium Ore
		smetalsZone = "Gathered whilst mining Khorium, Adamantite & Fel Iron."
	elseif itemId == "23425" then --Adamantite Ore
		smetalsZone = "Gathered in: Nagrand,\nBlade's Edge Mountains, Netherstorm\n&Shadowmoon Valley(Outland)."
	elseif itemId == "23424" then --Fel Iron
		smetalsZone = "Gathered across Outland.\nMost common in: Hellfire Peninsula,\nZangarmarsh & Nagrand."
	--The Burning Crusade Bars
	elseif itemId == "23447" then --Eternium
		smetalsZone = "Smelted by Miners using: 2 Eternium Ore."
	elseif itemId == "23449" then --Khorium
		smetalsZone = "Smelted by Miners using: 2 Khorium Ore."
	elseif itemId == "35128" then --Hardened Khorium
		smetalsZone = "Smelted by Miners using:\n3 Khorium Bars\n1 Hardened Adamantite Bar."
	elseif itemId == "23446" then --Adamantite Bar
		smetalsZone = "Smelted by Miners using: 2 Adamantite Ore."
	elseif itemId == "23448" then --Felsteel Bar
		smetalsZone = "Smelted by Miners using:\n3 Fel Iron Bars\n2 Eternium Bars."
	elseif itemId == "23445" then --Fel Iron
		smetalsZone = "Smelted by Miners using: 2 Fel Iron Ore."
	elseif itemId == "23573" then --Hardened Adamantite
		smetalsZone = "Smelted by Miners using: 10 Adamantite Bars."
	--Vanilla Ore
	elseif itemId == "11370" then --Dark Iron
		smetalsZone = "Gathered in: Molten Core & Blackrock Depths."
	elseif itemId == "3858" then --Mithril
		smetalsZone = "Gathered in: Thousand Needles,\nBadlands & Searing Gorge."
	elseif itemId == "10620" then --Thorium
		smetalsZone = "Gathered in: Winterspring,\nSilithus & Un'Goro Crater."
	elseif itemId == "7911" then --Truesilver
		smetalsZone = "Gathered in: Winterspring,\nThousand Needles & Burning Steppes."
	elseif itemId == "2772" then --Iron
		smetalsZone = "Gathered in: Feralas,\nDescolace & Western Plaguelands."
	elseif itemId == "2776" then --Gold
		smetalsZone = "Gathered in: Thousand Needles, Feralas & Eastern Plaguelands."
	elseif itemId == "2771" then --Tin
		smetalsZone = "Gathered in: Hillsbrad Foothills,\nAshenvale & Northern Stranglethorn."
	elseif itemId == "2775" then --Silver
		smetalsZone = "Gathered in: Feralas,\nNorthern Stranglethorn & Hillsbrad Foothills."
	elseif itemId == "2770" then --Copper
		smetalsZone = "Gathered in: Starting Zones,\nDarkshore & Northern Barrens."
	--Vanilla Bars
	elseif itemId == "17771" then --Enchanted Elementium
		smetalsZone = "Smelted by Miners using:\n1 Elementium Ingot\n10 Arcanite Bars\n1 Fiery Core\n3 Elemental Flux"
	elseif itemId == "12655" then --Enchanted Thorium
		smetalsZone = "Smelted by Miners using:\n1 Thorium Bar\n3 Rich Illusion Dust"
	elseif itemId == "12360" then --Arcanite
		smetalsZone = "Smelted by Miners using:\n1 Thorium Bar\n1 Arcane Crystal"
	elseif itemId == "11371" then --Dark Iron
		smetalsZone = "Smelted by Miners using:\n8 Dark Iron Ore"
	elseif itemId == "12359" then --Thorium
		smetalsZone = "Smelted by Miners using:\n1 Thorium Ore"
	elseif itemId == "6037" then --Truesilver
		smetalsZone = "Smelted by Miners using:\n1 Truesilver Ore"
	elseif itemId == "3860" then --Mithril
		smetalsZone = "Smelted by Miners using:\n1 Mithril Ore"
	elseif itemId == "3859" then --Steel
		smetalsZone = "Smelted by Miners using:\n1 Iron Bar\n1 Coal"
	elseif itemId == "3577" then --Gold
		smetalsZone = "Smelted by Miners using:\n1 Gold Ore"
	elseif itemId == "3575" then --Iron
		smetalsZone = "Smelted by Miners using:\n1 Iron Ore"
	elseif itemId == "2841" then --Bronze
		smetalsZone = "Smelted by Miners using:\n1Bronze Bar\n1 Tin Bar"
	elseif itemId == "3576" then --Tin
		smetalsZone = "Smelted by Miners using:\n1 Tin Ore"
	elseif itemId == "2842" then --Silver
		smetalsZone = "Smelted by Miners using:\n1 Silver Ore"
	elseif itemId == "2840" then --Copper
		smetalsZone = "Smelted by Miners using:\n1 Copper Ore"
	--Vanilla Others
	elseif itemId == "17203" then --Sulfuron Ingot
		smetalsZone = "Dropped by Golemagg the Incinerator.\nFound in Molten Core."
	elseif itemId == "12809" then --Guardian Stone
		smetalsZone = "Dropped by Stone Guardians\nFound in Un'Goro Crater."
	elseif itemId == "18567" then --Elemental Flux
		smetalsZone = "Sold by Blacksmith Suppliers."
	elseif itemId == "12644" then --Dense Grinding
		smetalsZone = "Crafted by Blacksmiths using:\n4 Dense Stone."
	elseif itemId == "12365" then --Dense Stone
		smetalsZone = "Gathered from Thorium Veins."
	elseif itemId == "7912" then --Solid Stone
		smetalsZone = "Gathered from Mithril Deposits."
	elseif itemId == "7966" then --Solid Grinding
		smetalsZone = "Crafted by Blacksmiths using:\n4 Solid Stone"
	elseif itemId == "3486" then --Heavy Grinding
		smetalsZone = "Crafted by Blacksmiths using:\n3 Heavy Stone"
	elseif itemId == "2838" then --Heavy Stone
		smetalsZone = "Gathered from Iron Deposits."
	elseif itemId == "3478" then --Coarse Grinding
		smetalsZone = "Crafted by Blacksmiths using:\n2 Coarse Stone"
	elseif itemId == "2836" then --Coarse Stone
		smetalsZone = "Gathered from Tin, Mithril & Truesilver Deposits."
	elseif itemId == "3470" then --Rough Grinding
		smetalsZone = "Crafted by Blacksmiths using:\n2 Rough Stone"
	elseif itemId == "2835" then --Rough Stone
		smetalsZone = "Gathered from Copper Veins."
	elseif itemId == "22202" then --Small Obsidian Shard
		smetalsZone = "Gathered in: Temple of Ahn'Qiraj Raid."
	elseif itemId == "22203" then --Large Obsidian Shard
		smetalsZone = "Gathered in: Temple of Ahn'Qiraj Raid."
	end
	
	return smetalsZone
end

namespace.metalsName = getMetalsZone
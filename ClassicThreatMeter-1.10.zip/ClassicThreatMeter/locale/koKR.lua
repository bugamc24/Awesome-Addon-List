local CTM, C, L, _ = unpack(select(2, ...))
if CTM.locale ~= "koKR" then return end

-----------------------------
--	koKR client
-----------------------------
-- main frame
L.gui_threat		= "위협"

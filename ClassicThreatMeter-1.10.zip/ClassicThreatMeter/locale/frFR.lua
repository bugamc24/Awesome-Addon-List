local CTM, C, L, _ = unpack(select(2, ...))
if CTM.locale ~= "frFR" then return end

-----------------------------
--	frFR client
-----------------------------
-- main frame
L.gui_threat		= "Menace"

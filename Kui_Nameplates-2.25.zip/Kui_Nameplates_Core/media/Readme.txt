All textures here are made for KuiNameplates by Kesava @ curse.com unless otherwise noted.

Sprites within state-icons.tga are borrowed from the Blizzard interface art files.
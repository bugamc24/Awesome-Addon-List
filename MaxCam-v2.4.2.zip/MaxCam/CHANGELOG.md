# MaxCam

## [v2.4.2](https://github.com/ketho-wow/MaxCam/tree/v2.4.2) (2019-08-27)
[Full Changelog](https://github.com/ketho-wow/MaxCam/compare/v2.4.1...v2.4.2)

- Fix Locales  

# RepHelper

## [8.2.0.2-release](https://github.com/chawan/RepHelper/tree/8.2.0.2-release) (2019-08-22)
[Full Changelog](https://github.com/chawan/RepHelper/compare/8.2.0.1-release...8.2.0.2-release)

- Travis  
- Travis stuff  
- Detailed chat messages now prints the next rank as well  
- Update README.md  
- Update README.md  
- Update issue templates  
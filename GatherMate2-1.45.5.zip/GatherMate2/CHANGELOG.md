# GatherMate2

## [1.45.5](https://github.com/Nevcairiel/GatherMate2/tree/1.45.5) (2019-09-26)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.45.3...1.45.5)

- Fix wintersbite error  

Grimoire Keeper
by Entropy, original vanilla addon by Artur Morozov (Artur91425)
Version 1.2

Tracks that grimoires your warlock pets have learned.

Every time you summon your pet the grimoires will be checked and saved. Also then you talk to a demon trainer the grimoires will be saved if you got your pet summoned. All learned grimoires will be marked as green in the demon trainer window.


Slash commands
/gk - display help
/gk list - List all saved grimoires.
/gk reset - Will empty list


Changelog:

1.1
* Added a check then summoning pet
* Added a check then using Grimoire spellbook
* Rewrote some functions to classes.

1.2
* Added language support
* Translation needed for text messages
* All spell should work on all languages

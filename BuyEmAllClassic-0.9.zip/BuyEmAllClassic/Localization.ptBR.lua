﻿-- Thanks to Phanx!

if GetLocale() == "ptBR" or GetLocale() == "ptPT" then
	BUYEMALL_LOCALS = {
	MAX				= "Máx",
	STACK			= "Pilha",
	CONFIRM			= "Tem certeza de que deseja comprar\n %d × %s?",
	STACK_PURCH		= "Comprar Pilha",
	STACK_SIZE		= "Tamanho da pilha",
	PARTIAL			= "Pilha parcial",
	MAX_PURCH		= "Máximo de compra",
	FIT				= "Tem espaço para",
	AFFORD			= "Tem dinheiro para",
	AVAILABLE		= "Comerciante tem",
}
end

local L = BUYEMALL_LOCALS;
﻿-- Thanks to Amshaegar! ( Included as an alternate since these are slightly different from the other translations I recieved. )

if GetLocale() == "ruRU" then
	BUYEMALL_LOCALS = {
	MAX 			= "Макс.",
	STACK 			= "Пачка",
	CONFIRM 		= "Вы уверены, что хотите купить\n %d x %s?",
	STACK_PURCH		= "Покупка пачкой",
	STACK_SIZE 		= "Размер пачки",
	PARTIAL 		= "Частичная пачка",
	MAX_PURCH		= "Максимальная покупка",
	FIT				= "Вы можете унести",
	AFFORD			= "Вы можете оплатить",
	AVAILABLE		= "У продавца есть",
}
end

local L = BUYEMALL_LOCALS;
﻿-- Thanks to jsr1976!

if GetLocale() == "esES" or GetLocale() == "esMX" then
	BUYEMALL_LOCALS = {
	MAX				= "Max",
	STACK			= "Montón",
	CONFIRM			= "Estas seguro que quieres comprar\n %d × %s?",
	STACK_PURCH		= "Montón Comprada",
	STACK_SIZE		= "Tamaño del Montón",
	PARTIAL			= "Montón Parcial",
	MAX_PURCH		= "Compra el Maximo",
	FIT				= "Puede caber",
	AFFORD			= "Puedes darte el lujo",
	AVAILABLE		= "Vendedor tiene",
}
end
 
local L = BUYEMALL_LOCALS;
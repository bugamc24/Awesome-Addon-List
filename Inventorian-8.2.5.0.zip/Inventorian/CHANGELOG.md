# Inventorian

## [8.2.5.0](https://github.com/Nevcairiel/Inventorian/tree/8.2.5.0) (2019-09-25)
[Full Changelog](https://github.com/Nevcairiel/Inventorian/compare/8.2.0.3...8.2.5.0)

- Update TOC for 8.2.5  
- Switch the portrait to a class icon when viewing a remote inventory  

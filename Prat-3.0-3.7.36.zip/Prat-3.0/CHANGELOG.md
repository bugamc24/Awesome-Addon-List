# Prat 3.0

## [3.7.36](https://github.com/sylvanaar/prat-3-0/tree/3.7.36) (2019-09-13)
[Full Changelog](https://github.com/sylvanaar/prat-3-0/compare/3.7.35...3.7.36)

- Make the k-strip non-greedy  

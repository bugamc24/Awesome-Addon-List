# HandyNotes

## [v1.5.9](https://github.com/Nevcairiel/HandyNotes/tree/v1.5.9) (2019-10-08)
[Full Changelog](https://github.com/Nevcairiel/HandyNotes/compare/v1.5.8...v1.5.9)

- Properly set classic interface version in TOC  

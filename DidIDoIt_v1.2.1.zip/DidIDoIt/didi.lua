local addonname, didi = ...
local questData = didi._questdb

local alreadyPrinted = {}
local reverseQuestData = {}

function didi:getFaction() -- preferred over UnitFactionGroup because not dependent on loading order
    local _, _, raceid = UnitRace("player")
    if raceid == 1 or raceid == 3 or raceid == 4 or raceid == 7 then
        return "Alliance"
    else
        return "Horde"
    end
end

-- REVERSE QUEST DATA FOR FUZZY NAME SEARCH
do
    for id, value in pairs(questData) do
        local name = string.lower(value[1])
        local faction = value[4]
        local player_faction = didi:getFaction()
        if faction == "Both" or faction == player_faction then
            reverseQuestData[name] = reverseQuestData[name] or {}
            table.insert(reverseQuestData[name], id)
        end
    end
end

function didi:getPrerequisites(id)
    local last = 0
    for _, k in pairs(questData[tonumber(id)][5]) do
        last = k
    end
    if last ~= 0 then
        self:getPrerequisites(last)
    end

    for _, k in pairs(questData[tonumber(id)][5]) do
        if (not self:tableContains(alreadyPrinted, k)) then
            self:printCompletionStatus(k)
            table.insert(alreadyPrinted, k)
        end
    end
end

function didi:getFollowUps(id)
    for _, k in pairs(questData[tonumber(id)][6]) do
        self:printCompletionStatus(k)
    end
end

function didi:printCompletionStatus(id)
    local questName
    if (self:tableHasKey(questData, tonumber(id))) then
        questName = questData[tonumber(id)][1]
    else
        questName = "|cffff0000MISSING_QUEST_NAME|r"
    end

    local completed = IsQuestFlaggedCompleted(tonumber(id))
    if (completed) then
        print(tonumber(id) .. ": " .. questName .. ":|cff10ff00 You did it!! :D")
    else
        print(tonumber(id) .. ": " .. questName .. ": You didn't do it! :(")
    end
end

function didi:fuzzyMatch(term)
    if type(term) == "string" and term:len() > 3 then
        term = string.lower(term)
        for name, data in pairs(reverseQuestData) do
            if string.find(name, term, 1, true) then
                print(questData[data[1]][1], unpack(data))
            end
        end
    end
end

function didi:tableHasKey(table, key)
    return table[key] ~= nil
end

function didi:tableContains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

SLASH_DIDI1 = "/didi"
SLASH_DIDI2 = "/dididoit"
SlashCmdList["DIDI"] = function(msg)
    if (tonumber(msg) ~= nil and string.len(msg) > 0) then
        print("|cffbaff00 Did I Do It? :: Completion status for " .. msg)

        if didi:tableHasKey(questData, tonumber(msg)) then
            didi:getPrerequisites(msg)
            alreadyPrinted = {}

            didi:printCompletionStatus(msg)

            didi:getFollowUps(msg)
            alreadyPrinted = {}
        else
            didi:printCompletionStatus(msg)
            print("        |cffff0000Missing data... please report this quest ID on the addon page at")
            print("        |rhttps://www.curseforge.com/wow/addons/did-i-do-it")
        end
    elseif type(msg) == "string" and msg:len() > 3 then
        didi:fuzzyMatch(msg)
    else
        print("Syntax: /didi {Quest ID}")
    end
end

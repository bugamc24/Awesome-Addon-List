# LibClassicItemSets-1.0

A library for WoW-Classic that contains all item sets with contained items and localization for the names.

## Usage

```lua
local ClassicItemSets = LibStub:GetLibrary("LibClassicItemSets-1.0")
```

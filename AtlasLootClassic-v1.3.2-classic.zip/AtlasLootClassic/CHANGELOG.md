# AtlasLootClassic

This mod is distributed under Version 2 of the GPL.  A copy of the GPL is included in this zip file with links to non-english translations.

[Changelog history](https://github.com/Hoizame/AtlasLootClassic/blob/master/AtlasLootClassic/Documentation/Release_Notes.md)

## v1.3.2 (Oct. 20, 2019)

- Add Boss level for Dire Maul bosses
- Add missing translations for Spanish big thanks @Rick !
- Also big thanks to all the other translators
- Fix some rare markers for LBRS thanks @wallrik

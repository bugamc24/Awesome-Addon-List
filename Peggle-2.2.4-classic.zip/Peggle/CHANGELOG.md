# Peggle (Unofficial)

## [2.2.4](https://github.com/ketho-wow/wow_peggle/tree/2.2.4) (2019-09-30)
[Full Changelog](https://github.com/ketho-wow/wow_peggle/compare/2.2.3...2.2.4)

- Fixed Peggle Battles  

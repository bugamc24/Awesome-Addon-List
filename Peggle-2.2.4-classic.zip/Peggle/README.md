"The Peggle Institute has opened a branch in Azeroth!"
A game made by PopCap Games, Inc. 

WoW Patch 1.13.2 Peggle Addon
An updated Peggle addon that has long abandoned.

Just download the zip and place the "Peggle" folder into the /Interface/AddOns/ folder.

Anybugs please use !Swatter/!BugGrabber addon to report issues.

Any help getting this addon to 100% is welcome.

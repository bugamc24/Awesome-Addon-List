local TN_TargetName
local TN_SavingNote
local TN_MouseoverName
local TN_InputName
local TN_SavingName

local TN_FunctionUsed

local Login_EventFrame = CreateFrame("Frame")
Login_EventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
Login_EventFrame:SetScript("OnEvent",
	function(self, event, ...)
	
			--parent box
			local f=TN_InputBox or CreateFrame("Frame","TN_InputBox",UIParent)
			f:SetSize(255,120)
			f:SetPoint("CENTER", 0, 100);
			f:SetBackdrop({
							bgFile = "Interface/DialogFrame/UI-DialogBox-Background-Dark",
							edgeFile = "Interface/DialogFrame/UI-DialogBox-Border",
							tile = true,
							tileSize = 32,
							edgeSize = 32,
							insets = { left = 10, right = 10, top = 10, bottom = 10 }
						});
			tinsert(UISpecialFrames,"TN_InputBox");

			--input box for the character name
			f=TN_NameBox or CreateFrame("EditBox","TN_NameBox",TN_InputBox,"InputBoxTemplate")
			f:SetSize(180,24)
			f:SetPoint("CENTER", "TN_InputBox", 20, 35);
			f:SetAutoFocus(false)
			f:SetScript("OnEnterPressed",function(s)
						TN_InputName = (s:GetText())
						TN_NoteBox:SetFocus()
						--print(TN_InputName)
					end)
			f:SetScript("OnShow", function(s)
						TN_InputName = nil
						if TN_FunctionUsed == true then
							TN_NameBox:SetText("")
							if TN_TargetName ~= nil then
								TN_NameBox:SetText(TN_TargetName)
								TN_InputName = TN_TargetName
								TN_NoteBox:SetFocus()
								--print(TN_InputName)
								--print("focusing notebox")
							end
							
							if TN_TargetName == nil then
								TN_NameBox:SetFocus()
								--print("focusing namebox")
							end
						end
					end)
					
					f:SetScript("OnEditFocusGained", function(s)

						if TN_FunctionUsed == true then
							TN_NameBox:SetText("")
							TN_NameBox:SetText(TN_TargetName)
							TN_InputName = TN_TargetName
							TN_NoteBox:SetFocus()
							--print(TN_InputName)
						end
					end)
					
			f:SetScript("OnEditFocusLost", function(s)

						TN_InputName = (s:GetText())

					end)
			f:CreateFontString("TN_NameText", OVERLAY, "GameFontNormal")
			TN_NameText:SetPoint("CENTER", "TN_NameBox", -115, 0);
			TN_NameText:SetText("Name:")

			--Input box for the note
			f=TN_NoteBox or CreateFrame("EditBox","TN_NoteBox",TN_InputBox,"InputBoxTemplate")
			f:SetSize(180,24)
			f:SetPoint("CENTER", "TN_NameBox", 0, -23);
			f:SetAutoFocus(false)
			f:SetScript("OnEnterPressed",function(s)
						TN_SavingNote = (s:GetText())
						TN_SavingName = TN_NameBox:GetText()
						if TN_SavingName ~= "" then
							TN_Database[TN_SavingName] = TN_SavingNote
							TN_InputBox:Hide()
							UIErrorsFrame:AddMessage("Note Saved", 255, 209, 0)
						else
							TN_NameBox:SetFocus()
						end
					end)
			f:SetScript("OnShow", function(s)

						TN_NoteBox:SetText("")
						if TN_TargetName ~= nil then
							TN_NoteBox:SetFocus()

						end
						if TN_FunctionUsed == true then
							TN_NoteBox:SetText("")
							TN_NoteBox:SetText(TN_Database[TN_TargetName])
						end
					end)
					
			f:SetScript("OnEditFocusGained", function(s)
			
						TN_InputNote = (s:GetText())
						if TN_TargetName == nil then
							TN_NoteBox:SetText("")
						end
						if TN_InputNote == "" then
							if TN_Database[TN_InputName] then
								TN_NoteBox:SetText("")
								TN_NoteBox:SetText(TN_Database[TN_InputName])
								--print(TN_InputName)
							end
						end
						
							if TN_FunctionUsed == true then
								TN_NoteBox:SetText("")
								TN_NoteBox:SetText(TN_Database[TN_TargetName])
							end

						TN_FunctionUsed = false

					end)		
			f:CreateFontString("TN_NoteText", OVERLAY, "GameFontNormal")
			TN_NoteText:SetPoint("CENTER", "TN_NoteBox", -113, 0);
			TN_NoteText:SetText("Note:")
			
			--Checkbox frames/text			
			f:CreateFontString("TN_CheckBoxText", OVERLAY, "GameFontNormal")
			TN_CheckBoxText:SetPoint("CENTER", "TN_InputBox", 0, -10);
			TN_CheckBoxText:SetText("Shift-clicking a player's name in chat:")
			
			f:CreateFontString("TN_ShowFrameText", OVERLAY, "GameFontNormal")
			TN_ShowFrameText:SetPoint("LEFT","TN_CheckBoxText", 0, -15);
			TN_ShowFrameText:SetText("Opens this menu:")
			
			f:CreateFontString("TN_ShowPrintText", OVERLAY, "GameFontNormal")
			TN_ShowPrintText:SetPoint("LEFT","TN_ShowFrameText", 0, -15);
			TN_ShowPrintText:SetText("Shows the player's note in chat:")
			
			f=TN_ShowFrameCheckBox or CreateFrame("CheckButton", "TN_ShowFrameCheckBox", TN_InputBox, "ChatConfigCheckButtonTemplate");
			f:SetPoint("RIGHT","TN_ShowFrameText", 23, -1);
			f:SetScript("OnClick", function()
						isChecked = TN_ShowFrameCheckBox:GetChecked()
						--print(isChecked)
							if isChecked == true then
								TN_ShowFrameOnClick = true
								--print(TN_ShowFrameOnClick)
							end
							if isChecked == false then
								TN_ShowFrameOnClick = false
								--print(TN_ShowFrameOnClick)
							end
						end)

			
			if TN_ShowFrameOnClick == true then
				TN_ShowFrameCheckBox:SetChecked(true)
			end

						
			f=TN_ShowPrintCheckBox or CreateFrame("CheckButton", "TN_ShowPrintCheckBox", TN_InputBox, "ChatConfigCheckButtonTemplate");
			f:SetPoint("RIGHT","TN_ShowPrintText", 23, -1);
			f:SetScript("OnClick", function()
						isChecked = TN_ShowPrintCheckBox:GetChecked()
						--print(isChecked)
							if isChecked == true then
								TN_ShowPrintOnClick = true
								--print(TN_ShowPrintOnClick)
							end
							if isChecked == false then
								TN_ShowPrintOnClick = false
								--print(TN_ShowPrintOnClick)
							end
						end)
						
			if TN_ShowPrintOnClick == true then
				TN_ShowPrintCheckBox:SetChecked(true)
			end
		
			TN_InputBox:Hide()
end)

SLASH_TN_Commands1 = "/tn"
SlashCmdList["TN_Commands"] = function(msg)
	TN_TargetName = UnitName("target")
	TN_FunctionUsed = true
	TN_NameBox:ClearFocus()
	TN_InputBox:Show()
	if TN_FunctionUsed == true then
		TN_NameBox:SetFocus()
	end
end

local function testDropdownMenuButton(self)
	if self.value == "TN_MenuButton" then
		TN_FunctionUsed = true
		TN_NameBox:ClearFocus()
		TN_InputBox:Show()
		if TN_FunctionUsed == true then
			TN_NameBox:SetFocus()
		end
	end
end


hooksecurefunc("ChatFrame_OnHyperlinkShow", function(chatFrame, link, text, button)
if (IsModifiedClick("CHATLINK")) then
  if (link and button) then

    local args = {};
    for v in string.gmatch(link, "[^:]+") do
      table.insert(args, v);
    end
		if (args[1] and args[1] == "player") then
			args[2] = Ambiguate(args[2], "short")
			TN_TargetName = args[2]
			TN_FunctionUsed = true
			TN_NameBox:ClearFocus()
			--print("next is shift-click")
			--print(TN_InputName)
			if TN_ShowFrameOnClick == true then
				TN_NameBox:ClearFocus()
				TN_InputBox:Show()
				if TN_FunctionUsed == true then
					TN_NameBox:SetFocus()
				end
			end
			--print(TN_InputName)
			if TN_InputName == "" or TN_InputName == nil then
				TN_NameBox:ClearFocus()
				if TN_FunctionUsed == true then
					TN_NameBox:SetFocus()
				end
			else
				TN_FunctionUsed = false
			end
			if TN_ShowPrintOnClick == true then
				if TN_Database[TN_TargetName] and TN_Database[TN_TargetName] ~= "" then
					DEFAULT_CHAT_FRAME:AddMessage('Note on ' .. TN_TargetName .. ': "' .. TN_Database[TN_TargetName] .. '"', 255, 209, 0)
				end
			end
		end
	end
end
end)

hooksecurefunc("UnitPopup_ShowMenu", function(dropdownMenu, which, unit, name, userData)

TN_TargetName = dropdownMenu.name

	if (UIDROPDOWNMENU_MENU_LEVEL > 1) then
	return
	end
		local info = UIDropDownMenu_CreateInfo()
			info.text = "Edit Tooltip Note"
			info.owner = which
			info.notCheckable = 1
			info.func = testDropdownMenuButton 
			info.value = "TN_MenuButton"
			UIDropDownMenu_AddButton(info)
end)

GameTooltip:HookScript("OnTooltipSetUnit", function(self)
  local _, unit = self:GetUnit()
  if UnitExists(unit) then
    TN_MouseoverName = UnitName(unit)
    if TN_Database[TN_MouseoverName] and TN_Database[TN_MouseoverName] ~= "" then
        GameTooltip:AddLine('"' .. TN_Database[TN_MouseoverName] .. '"', 255, 209, 0)
        GameTooltip:Show()
    end
  end
end)

local Addon_EventFrame = CreateFrame("Frame")
Addon_EventFrame:RegisterEvent("ADDON_LOADED")
Addon_EventFrame:SetScript("OnEvent",
	function(self, event, addon)
		if addon == "TooltipNotes" then
			TN_Database = TN_Database or {}
		end
end)
Name
----
Silver Rare Elites

Summary
-------
This small Addon adds the winged silver dragon frame to a Rare Elite

Description
-----------
In Vanilla World of Warcraft, Rare-Elite mobs had the same golden dragon unit frame as normal Elite mobs. With TBC, they got their own winged silver dragon (which is different from the one used by non-Elite Rare mobs).


In Classic, true to the creators' promise of restoring the original game, the golden dragon is used for Rare-Elites again.


However, I always thought it nice to be able to distinguish between normal Elite and Rare Elite mobs, since the mob's name is not always a dead giveaway (e.g. non-Rare Elite quest mob).


This small Addon replaces the golden dragon with the winged silver one for Rare-Elite mobs. It does this by checking the mob's classification (normal/rare/elite/rare-elite) and replacing the unit frame if it encounters a Rare-Elite.


I created this Addon for myself as I couldn't find one that did this small thing and I though maybe someone else would be happy too.
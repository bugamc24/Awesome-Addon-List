if GetLocale() ~= "frFR" then return end

-- Translate the strings here
CSC_DEFENSE                 = DEFENSE;
CSC_WEAPON_SKILLS_HEADER    = "Weapon Skills";

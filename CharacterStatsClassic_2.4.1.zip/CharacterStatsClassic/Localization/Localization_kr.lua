if GetLocale() ~= "koKR" then return end

-- Translate the strings here
CSC_DEFENSE                 = "방어";
CSC_WEAPON_SKILLS_HEADER    = "무기 기술";

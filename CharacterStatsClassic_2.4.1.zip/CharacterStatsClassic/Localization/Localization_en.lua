-- Custom global localized strings

CSC_DEFENSE                 = DEFENSE;
CSC_WEAPON_SKILLS_HEADER    = "Weapon Skills";

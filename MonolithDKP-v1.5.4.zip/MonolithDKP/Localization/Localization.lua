local _, core = ...;
local _G = _G;
local MonDKP = core.MonDKP;
local L = core.L;

core.LocalClass = {}

FillLocalizedClassList(core.LocalClass)
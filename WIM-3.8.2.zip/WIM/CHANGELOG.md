# WIM

## [3.8.2](https://github.com/sylvanaar/wow-instant-messenger/tree/3.8.2) (2019-10-09)
[Full Changelog](https://github.com/sylvanaar/wow-instant-messenger/compare/3.8.1...3.8.2)

- Fix typo in WindowHandler.lua  
FB_ODFTranslations["frFR"] = {
   DESCRIPTION = "Organise votre \195\169quipement.";

   -- Tab labels and tooltips
   OUTFITS_INFO = "Pr\195\169pare votre equipement de p\195\170che";
   OUTFITS = "Equipement";
   SHOWLOCATIONS_INFO = "Affiche vos prises class\195\169es par r\195\169gions.";

   SWITCHOUTFIT = "Equipement";
   SWITCHOUTFIT_INFO = "Vous habille avec votre \195\169quipement de p\195\170che, ou vous r\195\169habille comme avant.";

   CONFIG_SKILL_TEXT		= "P\195\170che ";

   BINDING_NAME_TOGGLEFISHINGBUDDY_OUT = "Toggle: #NAME# (Panneau d'\195\169quipement)";
};

--------------------------------------------
-- Creates all global variables for LOGIC --
--------------------------------------------

-- Hols the curent phase of the content patches on live servers
MTSL_CURRENT_PHASE = 1
-- Hols the max phase of game to ever be released on live servers
MTSL_MAX_PHASE = 6

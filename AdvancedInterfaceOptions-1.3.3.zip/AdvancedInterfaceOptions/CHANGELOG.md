# Advanced Interface Options

## [1.3.3](https://github.com/Stanzilla/AdvancedInterfaceOptions/tree/1.3.3) (2019-09-24)
[Full Changelog](https://github.com/Stanzilla/AdvancedInterfaceOptions/compare/1.3.2...1.3.3)

- Update TOC for Patch 8.2.5  
- Changed cameraDistanceMaxZoomFactor to 3.4 and nameplateMaxDistance to 20 in Classic  
    Removed mapFade in Classic  

# [2.15.4](https://github.com/WeakAuras/WeakAuras2/tree/2.15.4) (2019-10-16)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.15.3...2.15.4)

## Highlights

 - hot fix for cast bar issue on retail 

## Commits

mrbuds (1):

- cast trigger: don't hide cast bar on UNIT_SPELLCAST_FAILED fixes #1766


Auctionator.Constants.DebugLevels = {
  ERROR = 0,
  WARNING = 10,
  INFO = 80,
  SPAMMY_AF = 100
}
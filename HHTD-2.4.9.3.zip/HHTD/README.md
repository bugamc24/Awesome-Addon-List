H.H.T.D. for World of Warcraft
==============================

This is the official repository.

Download and documentation:

https://www.2072productions.com/to/HHTD.php

https://www.wowace.com/projects/h-h-t-d

Documentation is also available under the Doc/ directory:

    ./Doc/Description.md

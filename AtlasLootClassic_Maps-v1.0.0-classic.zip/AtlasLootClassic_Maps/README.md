# AtlasLootClassic_Maps

This contains map files for usage in AtlasLootClassic.

## Requirements

[AtlasLootClassic (Curseforge)](https://www.curseforge.com/wow/addons/atlaslootclassic)

[AtlasLootClassic (WoWInterface)](https://www.wowinterface.com/downloads/info25185-AtlasLootClassic.html)

## Credits

All credits for the map files go to the Atlas team.

[Atlas](https://www.curseforge.com/wow/addons/atlas)

## Information

This Module gets removed if the Atlas team updates Atlas for Classic.

# AtlasLoot [Maps]

## [v1.0.0](https://github.com/Hoizame/AtlasLootClassic_Maps/tree/v1.0.0) (2019-09-03)
[Full Changelog](https://github.com/Hoizame/AtlasLootClassic_Maps/commits/v1.0.0)

- travis  
- first commit  
- Initial commit  
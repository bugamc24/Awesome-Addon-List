# Neat Minimap
Neat Minimap auto hides/shows buttons and clutter as needed

## More information

Get the binary release using [curse](https://www.curseforge.com/wow/addons/neat-minimap)/twitch client or on wowinterface

The source of the addon resides on https://github.com/mooreatv/NeatMinimap
(and the MoLib library at https://github.com/mooreatv/MoLib)

Releases detail/changes are on https://github.com/mooreatv/NeatMinimap/releases

local aura = CreateFrame("Frame")
local combatlog = CreateFrame("Frame")

local Testing = false

local playerName = UnitName("player")
local playerGUID = UnitGUID("player")
local playerClass = select(2, UnitClass("Player"))
local buffs = spells[playerClass]

aura:RegisterEvent("UNIT_AURA", "player")
combatlog:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED", "player")


aura:SetScript("OnEvent", function(self, event, ...)
	--if (unit and unit ~= "player") then
	--	return
	--end

	-- Loop through all the buffs in table buffs.
	for buff in pairs(buffs) do
		-- Check if a buffs that has been applied and announce them.
		--print("K", buff)
		-- Loop through all player buffs.
		for i=1,40 do
			playerbuff = UnitBuff("player", i)
			if playerbuff ~= nil then
				--print("playerBuff:",playerbuff)
				for key,val in pairs(buffs[buff]) do					
					-- Check if the player has one of the buffs in table buffs.
					if playerbuff == buff then
						-- Check if the buff is set to false so we can announce it.
						if key == 1 then
							if not val then
								--print("You gained", playerbuff)
								Announce(buff)
								-- Supress announcements
								buffs[buff][key] = true
							end
						end
					end
				end
			end
		end
	end
	
	-- Checking for removed buffs to clear supressing annoucement flag.
	for buff in pairs(buffs) do
		buffExists = false
		for key,val in pairs(buffs[buff]) do
			if key == 1 then
				if val then
					for i=1,40 do
						if (UnitBuff("player", i) == buff) then
							buffExists = true
						end
					end
				end
			end
		end
		if not buffExists then
			--print("Buff does not exist:", buff)
			buffs[buff][1] = false
		end
	end
	
end)

combatlog:SetScript("OnEvent", function(self, event)
	self:OnEvent(event, CombatLogGetCurrentEventInfo())
end)

function combatlog:OnEvent(event, ...)
	local timestamp, subevent, _, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlags = ...
	local spellId, spellName, spellSchool
	local amount, overkill, school, resisted, blocked, absorbed, critical, glancing, crushing, isOffHand, missType, amountMissed
	
	-- Only report your own combatlog.
	if sourceGUID ~= playerGUID then
		--print("Filtered out data", subevent, sourceName, spellName)
		return
	end
	
	--print(subevent)
	if subevent == "SPELL_MISSED" then
		spellId, spellName, spellSchool, missType, isOffHand, amountMissed = select(12, ...)
		
		for _,taunt in pairs(taunts) do
			--print(taunt)
			if spellName == taunt then
				AnnounceMissedTaunt(sourceName, destName, spellName, missType)
			end
		end
	end
	
end

function Announce(buff)
	if Testing then
		print(string.format("%s %s - Channel: %s", playerName, buffs[buff][3], buffs[buff][2]))
	else
		SendChatMessage(string.format("%s %s", playerName, buffs[buff][3]), buffs[buff][2])
	end
end

function AnnounceMissedTaunt(sourceName, destName, spellName, missType)
	if Testing then
		print(string.format("%s: %s's %s failed on target %s!", missType, sourceName, spellName, destName))
	else
		SendChatMessage(string.format("%s: %s's %s failed on target %s!", missType, sourceName, spellName, destName), "YELL")
	end
end

function SpellAnnouncer()
	print("SpellAnnouncer loaded")
	--print(playerClass)
end

-----------------
-- Main Script --
-----------------

SpellAnnouncer()
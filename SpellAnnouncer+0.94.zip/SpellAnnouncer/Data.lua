spells = 
{
	["DRUID"] = 
	{
		["Frenzied Regeneration"] =
		{
			false,
			"YELL",
			"has used Frenzied Regeneration!",
		},
	},
	["HUNTER"] = 
	{
	
	},
	["MAGE"] = 
	{
		["Ice Block"] =
		{
			false,
			"YELL",
			"has used Ice Block!",
		},
	},
	["PALADIN"] = 
	{
		["Divine Shield"] =
		{
			false,
			"YELL",
			"has used Divine Shield!",
		},
	},
	["PRIEST"] = 
	{
	
	},
	["ROGUE"] = 
	{
		["Evasion"] = 
		{
			false,
			"YELL",
			"has used Evasion!",
		},
	},
	["SHAMAN"] = 
	{
	
	},
	["WARLOCK"] = 
	{
	
	},
	["WARRIOR"] = 
	{
		["Shield Wall"] =
		{
			false,
			"YELL",
			"has used Shield Wall!",
		},
		["Last Stand"] =
		{
			false,
			"YELL",
			"has used Last Stand!",
		},
	},
}
taunts = { "Taunt", "Mocking Blow", "Growl", }
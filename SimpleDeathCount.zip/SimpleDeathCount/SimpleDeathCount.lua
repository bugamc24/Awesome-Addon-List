local DeatchCount_EventFrame = CreateFrame("FRAME", "SimpleDeathCount", UIParent);
DeatchCount_EventFrame:SetMovable(true)
DeatchCount_EventFrame:EnableMouse(true)
DeatchCount_EventFrame:SetClampedToScreen(true)
DeatchCount_EventFrame:RegisterForDrag("LeftButton")
DeatchCount_EventFrame:SetScript("OnDragStart", DeatchCount_EventFrame.StartMoving)
DeatchCount_EventFrame:SetScript("OnDragStop", DeatchCount_EventFrame.StopMovingOrSizing)

DeatchCount_EventFrame:SetPoint("CENTER"); 
DeatchCount_EventFrame:SetWidth(128); 
DeatchCount_EventFrame:SetHeight(32);

text = DeatchCount_EventFrame:CreateFontString(nil,"ARTWORK") 
text:SetFont("Fonts\\ARIALN.ttf", 14, "OUTLINE")
text:SetPoint("LEFT",8,0)



DeatchCount_EventFrame:SetBackdrop({	bgFile = "Interface/Tooltips/UI-Tooltip-Background", 
																	edgeFile = "Interface/Tooltips/UI-Tooltip-Border", 
																	tile = true, tileSize = 16, edgeSize = 16, 
																	insets = { left = 4, right = 4, top = 4, bottom = 4 }
																});
DeatchCount_EventFrame:SetBackdropColor(0,0,0,1);


DeatchCount_EventFrame:RegisterEvent("PLAYER_DEAD");
DeatchCount_EventFrame:RegisterEvent("ADDON_LOADED");


function DeatchCount_EventFrame:OnEvent(event, arg1)
	if event == "ADDON_LOADED" and arg1 == "SimpleDeathCount" then
		if DeathCount == nil then
			DeathCount = 0;
		end
		text:SetText("|cffffffffDeathCount: " .. DeathCount)
	elseif event == "PLAYER_DEAD" then
		DeathCount = DeathCount + 1;
		text:SetText("|cffffffffDeathCount: " .. DeathCount)
	end
end


DeatchCount_EventFrame:SetScript("OnEvent", DeatchCount_EventFrame.OnEvent);



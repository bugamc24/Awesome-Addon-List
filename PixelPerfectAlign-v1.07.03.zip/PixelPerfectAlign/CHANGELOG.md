# Pixel Perfect Align

## [v1.07.03](https://github.com/mooreatv/PixelPerfectAlign/tree/v1.07.03) (2019-09-30)
[Full Changelog](https://github.com/mooreatv/PixelPerfectAlign/compare/v1.07.02-classic...v1.07.03)

- switching to github actions packaging, take 2  
- 8.2.5 toc and switching to github actions packaging, also picking up newer MoLib  
- test build  
- event registration and setsaved now in molib  
- Switching back to retail toc 80200  

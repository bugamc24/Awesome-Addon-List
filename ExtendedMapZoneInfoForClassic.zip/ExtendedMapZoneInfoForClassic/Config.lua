-- Get addon
local ExtendedMapZoneInfo = LibStub("AceAddon-3.0"):GetAddon("ExtendedMapZoneInfo")

-- Define option getter and setter
local optGet, optSet
do
	function optGet(info)
		local key = info[#info]
		return ExtendedMapZoneInfo.db.profile[key]
	end

	function optSet(info, val)
		local key = info[#info]
		ExtendedMapZoneInfo.db.profile[key] = val
	end
end

-- Define options
local options
local function getOptions()
	if not options then
		options = {
			type = "group",
			name = "Extended Map Zone Info",
			args = {
				general = {
					order = 1,
					type = "group",
					name = "General",
					get = optGet,
					set = optSet,
					args = {
						showProfSkillDesc = {
							order = 1,
							type = "description",
							name = "Show Profession Skill Levels"
						},
						showProfSkill = {
							order = 1.2,
							type = "toggle",
							name = "Enabled",
							desc = "Show recommended Profession Skill Levels when hovering a zone on the world map"
						}
					}
				}
			}
		}
	end
	return options
end

-- Define Options opener function (ex. for SlashCommands or Settings buttons)
local function optFunc()
InterfaceOptionsFrame_OpenToCategory(ExtendedMapZoneInfo.optionsFrames.ExtendedMapZoneInfo)
	InterfaceOptionsFrame_OpenToCategory(ExtendedMapZoneInfo.optionsFrames.ExtendedMapZoneInfo)
	InterfaceOptionsFrame:Raise()
end

-- Define setup funtion for main lua to use on initialize
function ExtendedMapZoneInfo:SetupOptions()
	self.optionsFrames = {}

	-- setup options table
	LibStub("AceConfigRegistry-3.0"):RegisterOptionsTable("ExtendedMapZoneInfo", getOptions)
	self.optionsFrames.ExtendedMapZoneInfo = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("ExtendedMapZoneInfo", nil, nil, "general")

	LibStub("AceConsole-3.0"):RegisterChatCommand("emzi", optFunc)
end
﻿-- Create the Addon Object (ACE3)
ExtendedMapZoneInfo = LibStub("AceAddon-3.0"):NewAddon("ExtendedMapZoneInfo", "AceConsole-3.0")

-- Define default settings for options
local defaultSettings = {
	profile = {
		showProfSkill = true;
	}
}

-- Define variables
local db
local GetQuestGreenRange = GetQuestGreenRange
local UnitLevel = UnitLevel
local GetCursorPosition = GetCursorPosition
local WorldMapScrollChild = WorldMapFrame.ScrollContainer.Child
-- Lua API function variables
local math_floor = math.floor
local select = select
local string_format = string.format
local string_gsub = string.gsub
local string_lower = string.lower
local unpack = unpack

-- Utility
----------------------------------------------------
-- Convert a Blizzard Color or RGB value set 
-- into our own custom color table format. 
local createColor = function(...)
	local tbl
	if (select("#", ...) == 1) then
		local old = ...
		if (old.r) then 
			tbl = {
}
			tbl[1] = old.r or 1
			tbl[2] = old.g or 1
			tbl[3] = old.b or 1
		else
			tbl = {
 unpack(old) }
		end
	else
		tbl = {
 ... }
	end
	if (#tbl == 3) then
		tbl.colorCode = ("|cff%02x%02x%02x"):format(math_floor(tbl[1]*255), math_floor(tbl[2]*255), math_floor(tbl[3]*255))
	end
	return tbl
end

-- Create our color table
local Colors = {
	normal = createColor(229/255, 178/255, 38/255),
	highlight = createColor(250/255, 250/255, 250/255),
	title = createColor(255/255, 234/255, 137/255),
	offwhite = createColor(196/255, 196/255, 196/255),
	profession = {
		blue = createColor(60/255, 227/255, 247/255)
	},
	faction = {
		friendly = createColor(64/255, 211/255, 38/255),
		contested = createColor(249/255, 188/255, 65/255),
		hostile = createColor(245/255, 46/255, 36/255)
	},
	quest = {

		red = createColor(204/255, 26/255, 26/255),
		orange = createColor(255/255, 128/255, 64/255),
		yellow = createColor(229/255, 178/255, 38/255),
		green = createColor(89/255, 201/255, 89/255),
		gray = createColor(120/255, 120/255, 120/255)
	}
}

-- Returns the correct difficulty color compared to the player
local GetQuestDifficultyColor = function(level, playerLevel)
	level = level - (playerLevel or UnitLevel("player"))
	if (level > 4) then
		return Colors.quest.red
	elseif (level > 2) then
		return Colors.quest.orange
	elseif (level >= -2) then
		return Colors.quest.yellow
	elseif (level >= -GetQuestGreenRange()) then
		return Colors.quest.green
	else
		return Colors.quest.gray
	end
end

-- Returns Mouse Normalized (Also compared to customized map)
function MouseXY()
	local left, top = WorldMapScrollChild:GetLeft(), WorldMapScrollChild:GetTop()
	local width, height = WorldMapScrollChild:GetWidth(), WorldMapScrollChild:GetHeight()
	local scale = WorldMapScrollChild:GetEffectiveScale()

	local x, y = GetCursorPosition()
	local cx = (x/scale - left) / width
	local cy = (top - y/scale) / height

	if cx < 0 or cx > 1 or cy < 0 or cy > 1 then
		return
	end

	return cx, cy
end

-- Zone Levels & Factions
local zoneData = {

	-- Eastern Kingdoms
	[1416] = { min = 27, max = 39, profSkillLevel = "135-195"}, 						-- Alterac Mountains
	[1417] = { min = 30, max = 40, profSkillLevel = "150-200" }, 						-- Arathi Highlands
	[1418] = { min = 36, max = 45, profSkillLevel = "180-225" }, 						-- Badlands
	[1419] = { min = 46, max = 63, profSkillLevel = "230-315" }, 						-- Blasted Lands
	[1428] = { min = 50, max = 59, profSkillLevel = "250-295" }, 						-- Burning Steppes
	[1430] = { min = 50, max = 60, profSkillLevel = "250-300" }, 						-- Deadwind Pass
	[1426] = { min =  1, max = 12, profSkillLevel = "1-20", faction = "Alliance" }, 	-- Dun Morogh
	[1431] = { min = 10, max = 30, profSkillLevel = "10-150" }, 						-- Duskwood
	[1423] = { min = 54, max = 59, profSkillLevel = "270-295" }, 						-- Eastern Plaguelands
	[1429] = { min =  1, max = 10, profSkillLevel = "1-10", faction = "Alliance" }, 	-- Elwynn Forest
	[1448] = { min = 47, max = 54, profSkillLevel = "235-270" }, 						-- Felwood
	[1424] = { min = 20, max = 31, profSkillLevel = "100-155" }, 						-- Hillsbrad Foothills
	[1432] = { min = 10, max = 18, profSkillLevel = "10-80", faction = "Alliance" }, 	-- Loch Modan
	[1433] = { min = 15, max = 25, profSkillLevel = "50-125" }, 						-- Redridge Mountains
	[1427] = { min = 43, max = 56, profSkillLevel = "215-280" }, 						-- Searing Gorge
	[1421] = { min = 10, max = 20, profSkillLevel = "10-100", faction = "Horde" }, 		-- Silverpine Forest
	[1434] = { min = 30, max = 50, profSkillLevel = "150-250" }, 						-- Stranglethorn Vale
	[1435] = { min = 36, max = 43, profSkillLevel = "180-215" }, 						-- Swamp of Sorrows
	[1425] = { min = 41, max = 49, profSkillLevel = "205-245" }, 						-- The Hinterlands
	[1420] = { min =  1, max = 12, profSkillLevel = "1-20", faction = "Horde" }, 		-- Tirisfal Glades
	[1436] = { min =  9, max = 18, profSkillLevel = "10-80", faction = "Alliance" }, 	-- Westfall
	[1422] = { min = 46, max = 57, profSkillLevel = "230-285" }, 						-- Western Plaguelands
	[1437] = { min = 20, max = 30, profSkillLevel = "100-150" }, 						-- Wetlands

	-- Kalimdor
	[1440] = { min = 19, max = 30, profSkillLevel = "90-150" }, 						-- Ashenvale
	[1447] = { min = 42, max = 55, profSkillLevel = "210-275" }, 						-- Azshara
	[1439] = { min = 11, max = 19, profSkillLevel = "10-90", faction = "Alliance" }, 	-- Darkshore
	[1443] = { min = 30, max = 39, profSkillLevel = "150-195" }, 						-- Desolace
	[1411] = { min =  1, max = 10, profSkillLevel = "1-10", faction = "Horde" }, 		-- Durotar
	[1445] = { min = 36, max = 61, profSkillLevel = "180-305" }, 						-- Dustwallow Marsh
	[1444] = { min = 41, max = 60, profSkillLevel = "205-300" }, 						-- Feralas
	[1450] = { min = 15, max = 15, profSkillLevel = "NONE" }, 							-- Moonglade
	[1412] = { min =  1, max = 10, profSkillLevel = "1-10", faction = "Horde" }, 		-- Mulgore
	[1451] = { min = 55, max = 59, profSkillLevel = "275-295" }, 						-- Silithus
	[1442] = { min = 15, max = 25, profSkillLevel = "50-125" }, 						-- Stonetalon Mountains
	[1446] = { min = 40, max = 50, profSkillLevel = "200-250" }, 						-- Tanaris
	[1438] = { min =  1, max = 11, profSkillLevel = "1-10", faction = "Alliance" }, 	-- Teldrassil
	[1413] = { min = 10, max = 33, profSkillLevel = "10-165", faction = "Horde" }, 		-- The Barrens
	[1441] = { min = 24, max = 35, profSkillLevel = "120-175" }, 						-- Thousand Needles
	[1449] = { min = 48, max = 55, profSkillLevel = "240-275" }, 						-- Un'Goro Crater
	[1452] = { min = 55, max = 60, profSkillLevel = "275-300" }  						-- Winterspring
}

-- OnUpdate Handlers
----------------------------------------------------
local AreaLabel_OnUpdate = function(self)
	self:ClearLabel(MAP_AREA_LABEL_TYPE.AREA_NAME)
	local map = self.dataProvider:GetMap()
	if (map:IsCanvasMouseFocus()) then
		local name, description, descriptionColor
		local mapID = map:GetMapID()
		local normalizedCursorX, normalizedCursorY = MouseXY()
		local positionMapInfo = C_Map.GetMapInfoAtPosition(mapID, normalizedCursorX, normalizedCursorY)	
		if (positionMapInfo and (positionMapInfo.mapID ~= mapID)) then
			name = positionMapInfo.name
			local playerMinLevel, playerMaxLevel, skinningSkillLevel, playerFaction
			if (zoneData[positionMapInfo.mapID]) then
				playerMinLevel = zoneData[positionMapInfo.mapID].min
				playerMaxLevel = zoneData[positionMapInfo.mapID].max
				professionsSkillLevel = zoneData[positionMapInfo.mapID].profSkillLevel
				playerFaction = zoneData[positionMapInfo.mapID].faction
			end
			if (playerFaction) then 
				local englishFaction, localizedFaction = UnitFactionGroup("player")
				if (playerFaction == "Alliance") then 
					description = string_format(FACTION_CONTROLLED_TERRITORY, FACTION_ALLIANCE) 
				elseif (playerFaction == "Horde") then 
					description = string_format(FACTION_CONTROLLED_TERRITORY, FACTION_HORDE) 
				end 
				if (englishFaction == playerFaction) then 
					description = Colors.faction.friendly.colorCode .. description .. FONT_COLOR_CODE_CLOSE
				else
					description = Colors.faction.hostile.colorCode .. description .. FONT_COLOR_CODE_CLOSE
				end 
			end
			if (name and playerMinLevel and playerMaxLevel and (playerMinLevel > 0) and (playerMaxLevel > 0)) then
				local playerLevel = UnitLevel("player")
				local color
				if (playerLevel < playerMinLevel) then
					color = GetQuestDifficultyColor(playerMinLevel, playerLevel)
				elseif (playerLevel > playerMaxLevel) then
					--subtract 2 from the maxLevel so zones entirely below the player's level won't be yellow
					color = GetQuestDifficultyColor(playerMaxLevel - 2, playerLevel)
				else
					color = Colors.quest.yellow
				end
				local profColor = Colors.profession.blue
				if (playerMinLevel ~= playerMaxLevel) then
					name = name..color.colorCode.." ("..playerMinLevel.."-"..playerMaxLevel..")"..FONT_COLOR_CODE_CLOSE
					if (db.showProfSkill) then
						name = name..string.char(10).."Profession Skill Level "..profColor.colorCode.."("..professionsSkillLevel..")"..FONT_COLOR_CODE_CLOSE
					end
				else
					name = name..color.colorCode.." ("..playerMaxLevel..")"..FONT_COLOR_CODE_CLOSE
					if (db.showProfSkill) then
						name = name..string.char(10).."Profession Skill Level "..profColor.colorCode.."("..professionsSkillLevel..")"..FONT_COLOR_CODE_CLOSE
					end
				end
			end
		else
			name = MapUtil.FindBestAreaNameAtMouse(mapID, normalizedCursorX, normalizedCursorY)
		end
		if name then
			self:SetLabel(MAP_AREA_LABEL_TYPE.AREA_NAME, name, description)
		end
	end
	self:EvaluateLabels()
end

-- Addon API
----------------------------------------------------
function ExtendedMapZoneInfo:SetUpZoneLevels()
	for provider in next, WorldMapFrame.dataProviders do
		if provider.setAreaLabelCallback then
			provider.Label:SetScript("OnUpdate", AreaLabel_OnUpdate)
		end
	end
end

-- Addon Initialization Code (Runs when addon is first loaded)
function ExtendedMapZoneInfo:OnInitialize()
	self.db = LibStub("AceDB-3.0"):New("ExtendedMapZoneInfoDB", defaultSettings, true)
	db = self.db.profile
	self:SetupOptions()
end

-- Code to run when the addon is enabled
function ExtendedMapZoneInfo:OnEnable()
    -- Called when the addon is enabled
	ExtendedMapZoneInfo:SetUpZoneLevels()
	ExtendedMapZoneInfo:Print("Extended Map Zone Info has been Enabled")
end

-- Code to run when the addon is disabled
function ExtendedMapZoneInfo:OnDisable()
    -- Called when the addon is disabled
	ExtendedMapZoneInfo:Print("Extended Map Zone Info has been Disabled")
end
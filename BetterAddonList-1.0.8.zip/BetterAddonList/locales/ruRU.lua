
if GetLocale() ~= "ruRU" then return end

local _, ns = ...
local L = ns.L



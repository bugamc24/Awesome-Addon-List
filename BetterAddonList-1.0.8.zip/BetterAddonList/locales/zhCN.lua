
if GetLocale() ~= "zhCN" then return end

local _, ns = ...
local L = ns.L



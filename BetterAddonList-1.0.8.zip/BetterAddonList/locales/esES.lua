
if GetLocale() ~= "esES" or GetLocale() ~= "esMX" then return end

local _, ns = ...
local L = ns.L




